package com.example.foodprint;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class FicheProduitActivity extends AppCompatActivity {


    private Vegetable ProduitChoisi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fiche_produit);

    }

    public void AjouterListe(View view) {


    }

    public void RetourGrid(View view) {


    }
}
